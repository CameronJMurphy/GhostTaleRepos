#pragma once
//#include "Map.h"


//this class represents the player
class ghost
{
protected:
	float startX =34 * 10.5;//34 is the tile size
	float startY =34 * 9.5;//34 is the tile size
	float posX = startX;//ghost current positionX
	float posY = startY; //ghost current positionY
	int ghostDrops = 0; //counter to see how many ghost drops have been collected


	/*struct tilesSurrounding
	{
		int left;
		int right;
		int down;
		int up;
	};*/


	
public:

	

	ghost();

	~ghost();

	void moveRight();
	void moveLeft();
	void moveDown();
	void moveUp();

	float xPos();

	float yPos();

	void setXPos(float pos);
	void setYPos(float pos);

	

	void reset();

	void collectDrop();

	int currentDrops();

	//tilesSurrounding centreImage(Map* level, ghost* player, int buffer);
	
	
};
