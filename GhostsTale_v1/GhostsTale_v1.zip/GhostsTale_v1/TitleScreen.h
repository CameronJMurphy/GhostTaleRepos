#pragma once

/*
class titleScreen : public aie::Application
{
protected:

	aie::Renderer2D*	m_2dRenderer;
	aie::Font*			m_font;
	aie::Texture*		wallTile;
	aie::Texture*		pacman;
	aie::Texture*		ghost;
	aie::Texture*		ghostDrop;
	aie::Texture*		title;

public:

	titleScreen() {};

	void printTitle();


};*/

void printTitle();